"""Schema-only response declarations, NOT handler response_model filters.

A frozen method/path/callable inventory prevents new routes from inheriting a
blanket policy. Source hashes are checked by the offline release gate, not HTTP.
Incomplete and external pass-through contracts are explicit, never counted as
fully modeled JSON. This module does not implement validation or redact errors.
"""
import json
from copy import deepcopy
from pathlib import Path

S = {'type': 'string'}
I = {'type': 'integer'}
F = {'type': 'number'}
B = {'type': 'boolean'}
N = {'type': 'null'}
DATE = {'type': 'string', 'format': 'date-time'}


def obj(**properties):
    return {'type': 'object', 'properties': properties, 'required': list(properties),
            'additionalProperties': False}


def array(items):
    return {'type': 'array', 'items': items}


def nullable(schema):
    return {'anyOf': [schema, N]}


def optional(schema, *names):
    schema = deepcopy(schema)
    schema['required'] = [k for k in schema['required'] if k not in names]
    return schema


def json_response(schema, description):
    schema = deepcopy(schema)
    definitions = {}
    def lift(value):
        if isinstance(value, dict):
            definitions.update(value.pop('$defs', {}))
            for child in value.values():
                lift(child)
        elif isinstance(value, list):
            for child in value:
                lift(child)
    lift(schema)
    if definitions:
        schema['$defs'] = definitions
    return {'description': description, 'content': {'application/json': {'schema': schema}}}


# Real dynamic JSON is limited to explicitly sourced user/tool/legacy fields.
# Never use this to invent an unknown operation's success shape.
JSON_VALUE = {'anyOf': [S, F, B, N, {'type': 'array', 'items': {'$ref': '#/$defs/JsonValue'}},
    {'type': 'object', 'additionalProperties': {'$ref': '#/$defs/JsonValue'}}]}
JSON_OBJECT = {'type': 'object', 'additionalProperties': {'$ref': '#/$defs/JsonValue'},
               'description': 'User-defined JSON key/value data; not a fixed application record.'}
PREFERENCES = obj(revision=I, delete_action={'enum': ['trash', 'permanent'], 'type': 'string'}, ask_before_delete=B,
    font_size=I, line_height=F, read_width=I, code_line_numbers=B, code_wrap=B,
    directory_sort={'enum': ['updated', 'title', 'created'], 'type': 'string'}, hidden_folders=array(S))
CODE_MESSAGE = obj(code=S, message=S)
DETAIL = {'anyOf': [S, CODE_MESSAGE, obj(code=S), obj(message=S),
    obj(message=S, editor=obj(ip=S, ua=S)), obj(code=S, current=PREFERENCES),
    obj(message=S, managed_settings=S),
    optional(obj(code={'const': 'protected_notes_folder'}, folder_id=S, message=S), 'message')]}
HTTP_ERROR = obj(detail=DETAIL)

OK = obj(ok=B)
UPLOAD = obj(id=S, url=S, filename=S)
USER = obj(id=S, username=S, display_name=S, is_admin=B, avatar_url=S, home_bg=S, email=S, email_verified=B)
SECURITY = obj(enabled=B, configured=B, elevated=B, expires_at=nullable(DATE), single_user=B, setup_required=B)
SESSION = obj(id=S, device=S, ip=S, remember=B, created_at=DATE, last_seen=DATE, expires_at=nullable(DATE), current=B, owner=S, mine=B,
    browser_id=nullable(S), browser_name=nullable(S), os_name=nullable(S), login_origin=nullable(S), ip_location=N)
SESSION_HISTORY = obj(**{**SESSION['properties'], 'expires_at':nullable(DATE)}, state={'type': 'string', 'enum': ['revoked', 'expired']})
MAIL_SENT = optional(obj(ok=B, minutes=I, already_sent=B), 'already_sent')
ZIP_ENTRY = obj(path=S, title=S, kind={'type': 'string', 'enum': ['directory', 'document', 'attachment']}, parent_path=nullable(S))
ZIP_PREVIEW = obj(entries=array(ZIP_ENTRY), warnings=array(S), counts=obj(documents=I, attachments=I))
ZIP_IMPORT = obj(documents=array(obj(id=S, title=S, path=S, parent_id=nullable(S))), attachments=I, warnings=array(S), reused=B)
CLIENT = obj(client_id=S, name=S, enabled=B, redirect_uris=array(S), has_secret=B, scopes=array(S), last_used_at=nullable(DATE))
CLIENT_SECRET = obj(**CLIENT['properties'], client_secret=S)
DISCOVERY = obj(**{k: S for k in ['issuer', 'authorization_endpoint', 'token_endpoint', 'userinfo_endpoint', 'jwks_uri']},
    **{k: array(S) for k in ['response_types_supported', 'subject_types_supported', 'id_token_signing_alg_values_supported',
        'scopes_supported', 'grant_types_supported', 'token_endpoint_auth_methods_supported', 'code_challenge_methods_supported', 'claims_supported']})
TIMELINE_ITEM = obj(kind=S, id=S, label=S, ts=DATE, node_id=nullable(I), path=S, state=nullable(S))
TIMELINE = obj(items=array(TIMELINE_ITEM), has_more=B, unknown_notes_present=B, history_path=nullable(S))
SEARCH = obj(items=array({'anyOf': [TIMELINE_ITEM, obj(kind={'const': 'note'}, id=S, label=S, path=S, ts=DATE),
    obj(kind={'const': 'node'}, id=S, label=S, path=S)]}))

_BASE = Path(__file__).parent
_SNAPSHOT = json.loads((_BASE / 'api_response_inventory.json').read_text())
SOURCE_EVIDENCE = _SNAPSHOT['sources']
INVENTORY = _SNAPSHOT['operations']
_OVERHAUL = json.loads((_BASE / 'api_response_overhaul.json').read_text())
SOURCE_EVIDENCE.update(_OVERHAUL['sources'])
INVENTORY = [*INVENTORY, *_OVERHAUL['operations']]
_WEB_PROJECTS = json.loads((_BASE / 'api_response_web_projects.json').read_text())
SOURCE_EVIDENCE.update(_WEB_PROJECTS['sources'])
INVENTORY.extend(_WEB_PROJECTS['operations'])
_BACKUPS = json.loads((_BASE / 'api_response_backups.json').read_text())
SOURCE_EVIDENCE.update(_BACKUPS['sources'])
INVENTORY.extend(_BACKUPS['operations'])
_FEEDBACK = json.loads((_BASE / 'api_response_feedback.json').read_text())
SOURCE_EVIDENCE.update(_FEEDBACK['sources'])
INVENTORY.extend(_FEEDBACK['operations'])
_INTEGRATED = json.loads((_BASE / 'api_response_integrated.json').read_text())
SOURCE_EVIDENCE.update(_INTEGRATED['sources'])
INVENTORY.extend(_INTEGRATED['operations'])
for _operation in INVENTORY:
    _operation['sources'] = sorted(set(_operation['sources']) | set(_INTEGRATED['source_additions'].get(_operation['endpoint'], [])))
_ENTRY_MONITORING = json.loads((_BASE / 'api_response_entry_monitoring.json').read_text())
SOURCE_EVIDENCE.update(_ENTRY_MONITORING['sources'])
INVENTORY.extend(_ENTRY_MONITORING['operations'])
for _operation in INVENTORY:
    _operation['sources'] = sorted(set(_operation['sources']) | set(_ENTRY_MONITORING['source_additions'].get(_operation['endpoint'], [])))
# Append the independently approved auth snapshot after scoped overlays;
# historical ledgers stay untouched and request evidence is linked, not a DTO.
_AUTH_REVIEW = json.loads((_BASE / 'api_response_auth_review.json').read_text())
SOURCE_EVIDENCE.update(_AUTH_REVIEW['sources'])
SOURCE_EVIDENCE['app.routers.auth.ProfileIn'] = _AUTH_REVIEW['new_request_source']
for _operation in INVENTORY:
    _operation['sources'] = sorted(set(_operation['sources']) | set(_AUTH_REVIEW['request_source_additions'].get(_operation['endpoint'], [])))
# Bounded independent R1 approval; retain historical evidence, retarget live references.
_ENTRY_SCOPE_REVIEW = json.loads((_BASE / 'api_response_entry_scope_review.json').read_text())
SOURCE_EVIDENCE.update(_ENTRY_SCOPE_REVIEW['sources'])
for _operation in INVENTORY:
    _operation['sources'] = sorted({_ENTRY_SCOPE_REVIEW['source_replacements'].get(_symbol, _symbol)
                                    for _symbol in _operation['sources']})
# Bounded independent round-four closure; historical ledgers remain immutable.
_ROUND4_REVIEW = json.loads((_BASE / 'api_response_round4_review.json').read_text())
SOURCE_EVIDENCE.update(_ROUND4_REVIEW['sources'])
INVENTORY.extend(_ROUND4_REVIEW['operations'])
for _operation in INVENTORY:
    _operation['sources'] = sorted(
        {_ROUND4_REVIEW['source_replacements'].get(_symbol, _symbol)
         for _symbol in _operation['sources']} |
        set(_ROUND4_REVIEW['source_additions'].get(_operation['endpoint'], [])))
_ROUND4_ENDPOINTS = frozenset(_ROUND4_REVIEW['affected_endpoints'])
# Apply the reviewed lane union AFTER round four, BEFORE DTO initialization.
# The new worker deliberately retains its stale expectation: NOT approved.
_V5_REVIEW = json.loads((_BASE / 'api_response_v5_integration.json').read_text())
SOURCE_EVIDENCE.update(_V5_REVIEW['sources'])
INVENTORY.extend(_V5_REVIEW['operations'])
_V5_MODELS = {(_item['method'], _item['path']): _item['model']
              for _item in _V5_REVIEW['inventory_model_replacements']}
for _operation in INVENTORY:
    _operation['sources'] = sorted({
        _V5_REVIEW['source_replacements'].get(_symbol, _symbol)
        for _symbol in [*_operation['sources'],
                        *_V5_REVIEW['source_additions'].get(_operation['endpoint'], [])]})
    _model = _V5_MODELS.get((_operation['method'], _operation['path']))
    if _model is not None:
        _operation['model'] = _model
# Final external alert source approval follows the monitor/channel union.
# Keep both prior overlays immutable, including the historical pending receipt.
_NODE_INTERRUPTION_REVIEW = json.loads((_BASE / 'api_response_node_interruptions_review.json').read_text())
SOURCE_EVIDENCE.update(_NODE_INTERRUPTION_REVIEW['sources'])
for _operation in INVENTORY:
    _operation['sources'] = sorted({
        _NODE_INTERRUPTION_REVIEW['source_replacements'].get(_symbol, _symbol)
        for _symbol in [*_operation['sources'],
                        *_NODE_INTERRUPTION_REVIEW['source_additions'].get(_operation['endpoint'], [])]})
_V5_HANDLERS = {**_ROUND4_REVIEW['handler_source_replacements'],
                **_V5_REVIEW['handler_source_replacements']}
for _operation in INVENTORY:
    _endpoint = _operation['endpoint']
    _symbol = _V5_HANDLERS.get(_endpoint, _endpoint)
    _symbol = _V5_REVIEW['source_replacements'].get(_symbol, _symbol)
    _V5_HANDLERS[_endpoint] = _NODE_INTERRUPTION_REVIEW['source_replacements'].get(_symbol, _symbol)
_NODE_INTERRUPTION_ENDPOINTS = frozenset(
    _operation['endpoint'] for _operation in INVENTORY
    if _V5_HANDLERS[_operation['endpoint']] in _NODE_INTERRUPTION_REVIEW['sources'])
_V5_ENDPOINTS = frozenset(_V5_REVIEW['affected_endpoints']) | frozenset(
    _operation['endpoint'] for _operation in INVENTORY
    if any(_symbol in _V5_REVIEW['sources'] for _symbol in _operation['sources']))
# Append the exact reviewed source/DTO union; historical JSON stays immutable.
# This loader is separately reviewable and is not a release approval.
_V6_REVIEW = json.loads((_BASE / 'api_response_v6_integration.json').read_text())
SOURCE_EVIDENCE.update(_V6_REVIEW['sources'])
_V6_ROWS = {(_row['method'], _row['path']): _row
            for _row in _V6_REVIEW['operation_source_updates']}
for _operation in INVENTORY:
    _reviewed = _V6_ROWS.get((_operation['method'], _operation['path']))
    if _reviewed is not None:
        if (_reviewed['endpoint'] != _operation['endpoint'] or
                _reviewed['before_sources'] != _operation['sources']):
            raise ValueError('v6 source-union precondition drift')
        _operation['sources'] = list(_reviewed['sources'])
_V5_HANDLERS.update(_V6_REVIEW['handler_source_replacements'])
_V6_ENDPOINTS = frozenset(
    _operation['endpoint'] for _operation in INVENTORY
    if any(_symbol in _V6_REVIEW['sources'] for _symbol in _operation['sources']))
# The current Agent approval already inherits the exact reviewed Ping methods.
# Never activate the superseded standalone Ping overlay.
_IPV6_UDP_REVIEW = json.loads((_BASE / 'api_response_ipv6_udp_source_review.json').read_text())
SOURCE_EVIDENCE.update(_IPV6_UDP_REVIEW['sources'])
for _operation in INVENTORY:
    _operation['sources'] = sorted({
        _IPV6_UDP_REVIEW['source_replacements'].get(_symbol, _symbol)
        for _symbol in [*_operation['sources'],
                        *_IPV6_UDP_REVIEW['source_additions'].get(_operation['endpoint'], [])]})
# Scoped v8 approval: exact before-source preconditions; retain all old ledgers.
_V8_REVIEW = json.loads((_BASE / 'api_response_v8_review.json').read_text())
SOURCE_EVIDENCE.update(_V8_REVIEW['sources'])
_V8_ROWS = {(_row['method'], _row['path']): _row
            for _row in _V8_REVIEW['operation_source_updates']}
for _operation in INVENTORY:
    _reviewed = _V8_ROWS.get((_operation['method'], _operation['path']))
    if _reviewed is not None:
        if (_reviewed['endpoint'] != _operation['endpoint'] or
                _reviewed['before_sources'] != _operation['sources']):
            raise ValueError('v8 source-union precondition drift')
        _operation['sources'] = list(_reviewed['sources'])
INVENTORY.extend(_V8_REVIEW['operations'])
_V5_HANDLERS.update(_V8_REVIEW['handler_source_replacements'])
_V8_ENDPOINTS = frozenset(_row['endpoint'] for _row in
                          [*_V8_REVIEW['operation_source_updates'], *_V8_REVIEW['operations']])
MODELS = json.loads((_BASE / 'api_response_models.json').read_text())
MODELS.update(_INTEGRATED['models'])
MODELS.update(_ENTRY_MONITORING['models'])
MODELS.update(_ROUND4_REVIEW['models'])
MODELS.update(_V5_REVIEW['models'])
MODELS.update(_V6_REVIEW['models'])
MODELS.update(_V8_REVIEW['models'])
VALIDATION_ITEM = MODELS['PublicValidationItem']
# The shared global/private builder emits only loc/type/msg. Explicit business
# HTTPException details remain separate and are not a global redaction promise.
VALIDATION_ERROR = obj(detail={'anyOf': [DETAIL, array(VALIDATION_ITEM)]})


def _replace_frontmatter(schema):
    """Document frontmatter really is JSONB; constrain values to JSON, not Any."""
    schema = deepcopy(schema)
    def visit(value):
        if isinstance(value, dict):
            if 'frontmatter' in value.get('properties', {}):
                value['properties']['frontmatter'] = nullable(JSON_OBJECT)
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    visit(schema)
    if '#/$defs/JsonValue' in json.dumps(schema):
        schema.setdefault('$defs', {}).setdefault('JsonValue', JSON_VALUE)
    return schema


def schema_holes(value, path='$'):
    """Identify unconstrained schema nodes, not arbitrary example/default objects."""
    holes = []
    if value == {} or value is True:
        return [path]
    if not isinstance(value, dict):
        return holes
    if value.get('type') == 'object' and not value.get('properties') and value.get('additionalProperties') is not False and not isinstance(value.get('additionalProperties'), dict):
        holes.append(path)
    if value.get('additionalProperties') is True:
        holes.append(path + '.additionalProperties')
    for key in ('properties', '$defs'):
        for name, child in value.get(key, {}).items():
            holes.extend(schema_holes(child, f'{path}.{key}.{name}'))
    for key in ('items', 'additionalProperties'):
        if key in value and value[key] is not False:
            holes.extend(schema_holes(value[key], f'{path}.{key}'))
    for key in ('anyOf', 'oneOf', 'allOf'):
        for i, child in enumerate(value.get(key, [])):
            holes.extend(schema_holes(child, f'{path}.{key}[{i}]'))
    return sorted(set(holes))


# Separate unfiltered ORM serialization from DocumentRead: PUT includes persisted
# draft_content/deleted_at/last_viewed_at, and does NOT invent has_draft.
DOCUMENT_ORM = obj(id=S, title=S, file_path=S, content=nullable(S), deleted_at=nullable(DATE),
    frontmatter=nullable(JSON_OBJECT), is_folder=B, visibility=S, is_pinned=B, is_favorite=B,
    status=S, word_count=nullable(I), content_hash=S, created_at=DATE, updated_at=DATE,
    updated_at_display=nullable(DATE),
    last_viewed_at=nullable(DATE), workspace_id=S, parent_id=nullable(S), draft_content=nullable(S),
    draft_updated_at=nullable(DATE), draft_device=nullable(S))
DOCUMENT_ORM['$defs'] = {'JsonValue': JSON_VALUE}

# Endpoint-name registrations below bind ONLY to exact frozen inventory rows.
# A newly added method/path, even with the same callable, stays unclassified.
SUCCESS = {}
DESCRIPTIONS = {row['endpoint']: row['review'] for row in _BACKUPS['operations']}
EXTRA_SOURCES = {}


def success(module, names, schema, description, *sources):
    for name in names.split():
        endpoint = 'app.routers.' + module + '.' + name
        SUCCESS[endpoint] = schema
        DESCRIPTIONS[endpoint] = description
        EXTRA_SOURCES[endpoint] = sources


success('attachment', 'upload', UPLOAD, 'Attachment reference; identical fields on idempotent replay.')
success('attachment', 'list_attachments', array(obj(**UPLOAD['properties'], mime=S, size=I, created_at=DATE,
    doc_id=S, doc_title=S, doc_in_trash=B)), 'Workspace document-bound attachment metadata including trash. Inner join excludes detached rows: doc_id stays non-null in this API; server-owned owner_id is never serialized.')
success('document', 'update_one', DOCUMENT_ORM, 'Unfiltered persisted document fields, including draft slots; no response_model filtering.', 'app/models/document.py')
success('document', 'preview_zip', ZIP_PREVIEW, 'Bounded ZIP preview; directory/document/attachment entries and unresolved-link warnings.')
success('document', 'import_zip', ZIP_IMPORT, 'Committed import result; reused=true on receipt replay, false on first commit.')
HTML_CONVERSION = obj(documents=array(obj(source=S,target=S,title=S,losses=array(S),markdown=S)),converted_count=I,original_path=S,source_sha256=S,warnings=array(S))
TEMPLATE_CATALOG = obj(root_id=nullable(S),items=array(obj(id=S,parent_id=S,title=S,is_folder=B)),recent_ids=array(S))
success('document', 'preview_html', HTML_CONVERSION, 'Inert bounded HTML conversion preview, explicit layout/script loss and retained original archive identity.')
success('document', 'import_html', obj(**ZIP_IMPORT['properties'],conversion=HTML_CONVERSION), 'Transactional converted notes and independent attachments; original bytes retained, idempotent replay supported.')
success('notes_tools', 'initialize_templates list_templates', TEMPLATE_CATALOG, 'Server-owned template root and currently valid descendants; up to two recent successful templates.')
success('notes_tools', 'copy_template save_template', _replace_frontmatter(MODELS['DocumentRead']), 'Independent copied document, latest template membership checked under document graph lock.')
# Project APIs return JSON metadata, never executable resource bytes. The latter
# are host middleware /p/<capability>/<path>, not mounted OpenAPI operations.
PROJECT_FILE = obj(id=S, path=S, kind={'enum': ['text', 'binary'], 'type': 'string'}, mime=S,
    size={'type': 'integer', 'minimum': 0}, updated_at=S)  # raw ISO CAS, not a display event
PROJECT_DIRECTORY = obj(id=S, path=S, kind={'const': 'directory'})
PROJECT_MANIFEST = obj(id=S, workspace_id=S, title=S, entry=nullable(S), entry_file_id=nullable(S),
    files=array(PROJECT_FILE), directories=array(PROJECT_DIRECTORY))
PROJECT_RENEWAL = obj(capability={'type': 'string', 'pattern': '^[A-Za-z0-9_-]{43}$'},
    epoch={'type': 'integer', 'minimum': 0, 'maximum': 9007199254740991},
    expires_in={'const': 900, 'type': 'integer'}, renew_after={'const': 840, 'type': 'integer'})
DETACHED_ITEM = obj(id=S, workspace_id=S, title=S, kind={'const': 'detached-source'}, mime=S, updated_at=S)
DETACHED_SOURCE = obj(**DETACHED_ITEM['properties'], content=S)
PROJECT_STATE = obj(revision={'type': 'integer', 'minimum': 0}, epoch={'type': 'integer', 'minimum': 0},
    data={'type': 'object', 'additionalProperties': S, 'maxProperties': 1000,
          'description': 'User webpage localStorage strings; serialized UTF-8 JSON budget 1 MiB. No IndexedDB or JS heap snapshot.'})
PROJECT_SOURCE = {'oneOf': [
    obj(**{**PROJECT_FILE['properties'], 'kind': {'const': 'text'}}, content=S, url=N),
    obj(**{**PROJECT_FILE['properties'], 'kind': {'const': 'binary'}}, content=N, url=S)]}
success('web_projects', 'catalog', array(PROJECT_MANIFEST), 'Owner workspace active project manifests; no original attachment IDs or grant internals.')
success('web_projects', 'preview', obj(files=array(obj(path=S, size={'type': 'integer', 'minimum': 0},
    kind={'enum': ['text', 'binary'], 'type': 'string'})), entries=array(S), suggested_entry=nullable(S), warnings=array(S)),
    'Bounded ZIP/HTML metadata preview; multiple non-index HTML candidates require explicit choice. No project is written.')
success('web_projects', 'import_project', obj(id=S, reused=B), 'HTTP 200 on first import and exact receipt replay; not a full manifest. UUID encoded as string.')
success('web_projects', 'manifest', PROJECT_MANIFEST, 'Current relative paths; entry is null after moving/deleting entry out of the active project. Invalid/duplicate paths fail 409.')
success('web_projects', 'source', PROJECT_SOURCE, 'Text content with null URL, or binary metadata with null content and owner-authenticated attachment URL; not resource bytes.')
success('web_projects', 'update_source', obj(id=S, updated_at=S, content=S), 'Saved source and raw ISO CAS token; invalid version 422, binary or stale version 409. No automatic runtime reload.')
success('web_projects', 'state', PROJECT_STATE, 'Owner state projection; absent state is revision=epoch=0, data={}. Internal write_id/digest are omitted.')
success('web_projects', 'write_state', PROJECT_STATE, 'Cookie owner plus exact Origin and project/session/epoch-bound capability, revalidated under locks. Exact write receipt replay returns same state; stale/different replay 409.')
success('web_projects', 'reset', PROJECT_STATE, 'HTTP 200 JSON, not 204: revision and epoch increment; data cleared, files unchanged. Previous runtime grants become invalid.')
success('web_projects', 'launch', obj(url=S, capability={'type': 'string', 'pattern': '^[A-Za-z0-9_-]{43}$'},
    source_origin=S, target_origin=S, state=PROJECT_STATE, expires_in={'const': 900, 'type': 'integer'}),
    'Owner cookie, presented live session and exact Origin required. Registered separate runtime origin, 900-second opaque grant, current state; not redirect or bootstrap POST fields. Supersedes same-session/project grant; no user credentials in runtime URL.')
success('web_projects', 'copy_asset', UPLOAD, 'Independent target-note attachment reference; same request ID/scope replay returns identical fields, not a reused flag.')
success('web_projects', 'renew', PROJECT_RENEWAL, 'In-place renewal of the same capability; live original owner SID, exact Origin, target and epoch rechecked after locks. Expired access remains denied during 300s renewal grace. Never creates a missing grant, returns state, reloads iframe, or changes source.')
success('project_files', 'update_entry', PROJECT_MANIFEST, 'Owner-locked entry CAS: expected_entry_file_id required but nullable; stale token or non-member/non-HTML/binary candidate 409. Returns full current manifest, no runtime reload.')
success('detached_sources', 'catalog', array(DETACHED_ITEM), 'Owner workspace private active detached text source identities; no source text, original path, root/owner provenance or grant internals.')
success('detached_sources', 'read save', DETACHED_SOURCE, 'Same original private Document identity and raw ISO CAS. PUT returns full source projection; Unicode/NUL 422, UTF-8 >5 MiB 413, stale CAS 409. No owner_id/source_root_id/original_path metadata.')
success('document', 'finalize_import', obj(synced=I), 'Number of imported documents whose links were synchronized.')
success('document', 'empty_trash_endpoint', obj(purged=I), 'Count of permanently removed trash documents.')
success('document', 'clear_all_endpoint', obj(trashed=I), 'Count moved to trash, not a permanent deletion.')
success('document', 'restore_one', obj(doc=_replace_frontmatter(MODELS['DocumentRead']), reattached=B, restored=I),
    'Restored document, root reattachment flag and restored count.')
success('document_version', 'diff_version', obj(version_id=S, against=nullable(S), diff=S), 'Unified text diff against current document or explicit version.')
success('notes_tools', 'read_node link_node', obj(node_id=nullable(I)), 'Linked node ID, or null when no node is associated.')
success('auth', 'register login refresh me update_profile upload_avatar login_by_code verify_email_code pick_avatar', USER,
    'Owner profile projection; session issuance/rotation is conveyed separately by Set-Cookie.')
success('auth', 'security', SECURITY, 'Compatibility status for authenticated owner; no independent management protection or grant.')
success('auth', 'update_security change_management_password admin_setup admin_lock logout revoke_session', OK, 'Operation acknowledgement.')
success('auth', 'status', obj(has_users=B, initialized=B, email_enabled=B, single_user=B), 'Single-owner initialization and email availability.')
success('auth', 'activity', obj(ok=B, expires_at=DATE), 'Explicit activity acknowledgement and session expiry.')
success('auth', 'change_password reset_password', obj(ok=B, hint=S), 'Password change acknowledgement; all sessions are revoked.')
success('auth', 'email_service_status', obj(ready=B, configured=B, enabled=B), 'Email-service availability, without SMTP credentials.')
success('auth', 'send_email_code forgot_password send_login_code resend_code', MAIL_SENT,
    'Code send acknowledgement; already_sent appears only for an existing valid code.')
success('auth', 'session_location', obj(ip=S, ip_location=nullable(S)), 'Opt-in bounded lookup of an owner session IP; null on unavailable external lookup.', 'app/services/session_location.py')
success('auth', 'my_sessions', array(SESSION), 'Owner-only active sessions, access SID current identity and policy expiry (not online status). current_only bypasses pagination; exclude_current filters before pagination. Reads never extend expiry.')
success('auth', 'session_history', obj(items=array(SESSION_HISTORY), total=I, page=I, page_size=I), 'Owner-only inactive session history page.')
success('admin_email', 'put_config', OK, 'SMTP configuration save acknowledgement, both local and shared-state modes.')
success('admin_email', 'test_mail', obj(ok=B, to=S), 'SMTP test delivery acknowledgement.')
success('alerts', 'create_rule', obj(id=I), 'Created alert rule ID.')
success('alerts', 'patch_rule delete_rule mark_read', OK, 'Alert/notification acknowledgement.')
success('alerts', 'mark_all_read', obj(ok=B, marked=I), 'Bulk-read acknowledgement and affected count.')
success('alerts', 'unread_count', obj(count=I), 'Unread notification count.')
success('alerts', 'list_events', array(obj(id=I, rule_id=I, event=S, ts=DATE, message=S)), 'Alert event records.')
success('alerts', 'list_notifications', array(obj(id=I, rule_id=nullable(I), title=S, body=S, severity=S, kind=S, link=S, read=B, ts=DATE)), 'Notification records.')
success('alerts', 'list_rules', array(optional(obj(id=I, kind=S, target=S, label=S, link=S, severity=S, debounce=I,
    repeat_minutes=I, email=B, enabled=B, created_at=DATE, state=S, last_change_at=nullable(DATE), message=nullable(S),
    wg_manual=nullable(obj(node_id=I,interface=S,target=S,interface_key_id=S,peer_key_id=S)),
    wg_observation=obj(health={'enum':['ok','degraded','failed','unknown']},reason=nullable(S),checked_at=nullable(DATE))),
    'wg_manual','wg_observation')), 'Rules with current state slots and optional bound manual WG observation.')
success('monitor', 'install_command', obj(url=S, token=S, command=S), 'Sensitive single-node install command; no-store.')
success('monitor', 'get_host', obj(os=S, installed=B, local_install_supported=B, node_id=nullable(I), node_status=nullable(S)), 'Local host installation metadata.')
success('monitor', 'agent_report', obj(ok=B, node_id=I, status=S, monitors_version=I), 'Agent report receipt and current node/config state.')
success('monitor', 'agent_mtr_report agent_monitor_check', OK, 'Agent result acknowledgement.')
success('monitor', 'agent_version', {'anyOf': [obj(version=S), obj(version=S, sha256=S, size=I)]}, 'Version-only fallback or script integrity manifest.')
success('task', 'cancel_iperf finish_iperf iperf_progress finish_component finish_net_task mtr_live finish_command finish_uninstall', OK, 'Task acknowledgement.')
success('task', 'get_iperf_status', obj(status=S), 'Current task status.')
success('task', 'finish_mtr', N, 'Implicit JSON null response (not 204).')
success('config', 'get_public_host get_site_background', obj(value=S), 'Configured value, or empty string.')
success('config', 'set_public_host', obj(ok=B, value=S), 'Saved public host value.')
success('homebg', 'delete_homebg', OK, 'Background deletion acknowledgement.')
success('drive', 'status', obj(configured=B, auth_mode=S), 'Drive configuration status.')
success('drive', 'connection save_connection', obj(service_url=S, auth_mode=S, has_token=B), 'Masked drive connection; no token value.')
success('drive', 'test_connection', obj(ok=B, message=S, warning=S), 'Probe result; failures can be HTTP 200 with ok=false.')
success('drive', 'reveal_token', obj(token=S), 'Sensitive token disclosure; no-store.')
success('drive', 'login_url', obj(url=S), 'Credential-free local proxy launch URL.')
success('gallery', 'status', obj(configured=B, browser_url=S, auth_mode=S), 'Gallery configuration status.')
success('gallery', 'test_connection', obj(ok=B, message=S, warning=S), 'Probe result; failures can be HTTP 200 with ok=false.')
success('oidc', 'openid_configuration', DISCOVERY, 'OIDC discovery metadata.')
success('oidc', 'token', obj(access_token=S, token_type=S, expires_in=I, id_token=S, scope=S), 'Authorization-code exchange result, never a browser session token.')
success('oidc', 'userinfo', optional(obj(sub=S, name=S, preferred_username=S, email=S), 'name', 'preferred_username', 'email'), 'Claims depend on granted profile/email scopes; sub is always present.')
success('auth_provider', 'clients', array(CLIENT), 'Registered clients; secrets are not returned.')
success('auth_provider', 'client update', CLIENT, 'Public registered-client projection.')
success('auth_provider', 'create rotate', CLIENT_SECRET, 'One-time client-secret delivery with public client fields.')
success('auth_provider', 'delete', OK, 'Client deletion acknowledgement.')
success('auth_provider', 'reveal', obj(client_id=S,client_secret=S), 'Sensitive same-Origin POST of an existing secret; current owner/admin rechecked after lock, no-store on success and denial. No generation/rotation/version change.')
success('auth_provider', 'provider_config', obj(**{k:S for k in ['issuer','authorization_endpoint','token_endpoint','userinfo_endpoint','jwks_uri','discovery_url']},
    clients=array(CLIENT), capabilities=obj(grant_types_supported=array(S), token_endpoint_auth_methods_supported=array(S),
    code_challenge_methods_supported=array(S), scopes_supported=array(S), secret_reveal=B)), 'Provider endpoints, client projections and capability metadata.')
success('timeline', 'read_timeline', TIMELINE, 'Bounded metadata events; timestamps are event/creation times, not invented completion times.')
success('unified_search', 'search', SEARCH, 'Bounded metadata union of notes, nodes and timeline records; node hits omit ts.')


HELP = obj(title=S, location=nullable(S), instructions=array(S), external_url=nullable(S))
# Optional on transport failures and historical receipts; explicit HTML product
# hints and inert Stella appearance code are observations, never authority.
WEBSITE_CHECK = optional(obj(normalized_url=S, name_suggestion=S, access=obj(status=S, http_status=nullable(I)),
    embedding=obj(status=S, reason_code=S, reason=S), injection=obj(status=S, reason=S), help=nullable(HELP),
    can_save=B, recommended_behavior=S, issues=array(S),
    software=obj(type={'type':'string','enum':['unknown','openlist','immich']}, source=nullable({'type':'string','enum':['html:generator','html:application-name']})),
    compatibility=nullable(obj(enabled=B, css=S, js=S, timing={'type':'string','enum':['document_start','dom_ready']}))), 'software', 'compatibility')
# Use the same reviewed check DTO in success AND nested HTTP-error consumers.
WEBSITE_CHECK = deepcopy(MODELS['PublicWebsiteCheck'])
DETAIL['anyOf'].extend([obj(errors=array(S)), obj(code=S, check=WEBSITE_CHECK),
    obj(code={'const':'incomplete_injection'}, projection=obj(state={'const':'incomplete'}, invalid_fields=array(S)))])
CONNECTION = obj(browser_url=S, upstream_url=S, alternate_browser_url=S, use_proxy=B, auth_mode=S, has_token=B)
PORTABLE_CONNECTION = obj(transport=S, auth_mode=S, header_name=S, injection_delivery=S)
CUSTOM = obj(enabled=B, css=S, js=S, timing=S)
REQUEST_POLICY = obj(management_prefixes=array(S), read_post_paths=array(S), protect_other_writes=B)
PORTABLE_DRAFT = optional(obj(name=S, icon=S, open_behavior=S, keep_alive=B, background=S,
    custom=CUSTOM, connection=PORTABLE_CONNECTION, request_policy=REQUEST_POLICY), 'name')
# Builtin drafts omit keep_alive; catalog records now carry builtin provenance.
BUILTIN_DRAFT = optional(PORTABLE_DRAFT, 'keep_alive')
BUILTIN_TEMPLATE = obj(id=S, name=S, provenance={'const': 'builtin'}, description=S, draft=BUILTIN_DRAFT)
SAVED_TEMPLATE = obj(id=S, name=S, provenance={'const': 'user'}, description=S, draft=PORTABLE_DRAFT)
MEDIA_METADATA = optional(obj(url=S, status=S, poster=nullable(S), thumbnail=nullable(S),
    variants={'type':'object','additionalProperties':S}, error=S, width=I, height=I), 'error','width','height')
BACKGROUND = obj(media=MEDIA_METADATA, id=S, name=S, ext=S, url=S, isDefault=B, isSystem=B, owner=nullable(S))
LAUNCH = {'anyOf': [optional(obj(mode=S, url=S, method={'const': 'GET'}, target_origin=S), 'target_origin'),
    obj(mode={'const': 'isolated_proxy'}, url=S, source_origin=S, target_origin=S,
        method={'const': 'POST'}, fields=obj(ticket=S), expires_in=I, entry_revision=I)]}
success('gallery', 'connection save_connection', CONNECTION, 'Masked external connection; no token/clear_token field.')
success('website_settings', 'check', WEBSITE_CHECK, 'Bounded server-side probe observations; not proof of browser embedding or login.')
success('website_settings', 'templates', array(BUILTIN_TEMPLATE), 'Built-in inert template catalog on this baseline; upstream saved-template delta is recorded separately.')
success('homebg', 'get_media optimize_homebg', MEDIA_METADATA, 'Media derivative metadata; missing/queued/processing/ready/error modes have optional size/error fields.')
success('homebg', 'list_homebg', array(BACKGROUND), 'Visible background records with media derivative metadata.')
success('homebg', 'upload_homebg rename_homebg', BACKGROUND, 'Background record; local queue versus synchronous PostgreSQL optimization uses the same optional media fields.')
success('operations_status','backup_health',obj(timestamp=nullable(S),status={'type':'string','enum':['missing','invalid','verified','unverified','failed','stale']},checksumverified=B,restoreverified=B,source={'anyOf':[{'enum':['postgres-dump','postgres-snapshot']},N]}),'Read-only backup receipt projection; no backup/restore operation is performed.')
success('metrics_source','get_connection put_connection',obj(enabled=B,url=nullable(S),nodes={'type':'object','additionalProperties':obj(job=S,instance=S)}),'Explicit Prometheus comparison configuration; node-keyed typed target mappings.')
success('monitor','read_traffic_stats',obj(rx_95=F,tx_95=F,rx_max=F,rx_min=F,tx_max=F,tx_min=F,rx_total=I,tx_total=I,sample_count=I),'Aggregated interface traffic statistics; empty aggregates normalize to zero.')
success('integrations','resolve_target',obj(normalized_origin=S,resolved_ips=array(S),status=S,private_addresses=B),'Resolved/pinned address preview, not a saved integration.')
success('integrations','launch',LAUNCH,'GET browser launch or isolated-proxy POST bootstrap with ticket fields and expiry.')
success('integrations','presets',obj(openlist=obj(css=S,js=S,readonly=B,status=S,managed_settings=S),immich=obj(css=S,js=S,readonly=B,status=S,managed_settings=S),generic=obj(css=S,js=S,readonly=B,status=S)),'Read-only code presets; generic injection-loaded is not application-ready.')


def _media(description, mime='*/*'):
    return {'description': description, 'content': {mime: {'schema': {'type': 'string', 'format': 'binary'}}}}


def _error_responses(record):
    result = {code: json_response(HTTP_ERROR, 'Application/dependency HTTPException; string or documented structured detail.')
              for code in record['error_statuses']}
    if record.get('request_validation') or '422' in result:
        result['422'] = json_response(VALIDATION_ERROR, 'Shared public request-validation builder (loc/type/msg), or explicit business HTTPException detail; no global error/log redaction claim.')
    # Backup conflicts are closed, per-operation envelopes. The maintenance CLI
    # command is not an arbitrary global HTTPException detail or a JSON success.
    conflict_codes = {
        'app.routers.backups.patch': ['backup_busy', 'revision_conflict'],
        'app.routers.backups.save_client_preferences': ['revision_conflict'],
        'app.routers.backups.backup': ['backup_busy'],
        'app.routers.backups.verify': ['backup_busy'],
        'app.routers.backups.restore': ['backup_busy', 'revision_conflict'],
        'app.routers.backups.delete': ['backup_busy'],
    }.get(record['endpoint'])
    if conflict_codes is not None:
        details = [obj(code={'type': 'string', 'enum': conflict_codes}, message=S)]
        if record['endpoint'] == 'app.routers.backups.restore':
            details.append(obj(code={'type': 'string', 'const': 'maintenance_required'}, message=S, command=S))
        result['409'] = json_response(obj(detail={'anyOf': details}), 'Backup operation conflict; only all-scope restore adds the required offline maintenance command.')
    return result


INCOMPLETE_REASONS = {}


from app.api_response_shapes import register as _register_shapes
SHAPE_BLOCKERS, CURRENT_SHAPES = _register_shapes(globals())
from app.api_response_feedback import register as _register_feedback
SHAPE_BLOCKERS.update(_register_feedback(globals()))
INCOMPLETE_REASONS.update(SHAPE_BLOCKERS)

DECLARATIONS = {}
for _row in INVENTORY:
    _key = (_row['method'], _row['path'])
    _endpoint = _row['endpoint']
    _responses = _error_responses(_row)
    _status, _reason = 'reviewed', ''
    _description = DESCRIPTIONS.get(_endpoint, '')
    _payload = SUCCESS.get(_endpoint)
    if _payload is None and 'model' in _row:
        _payload = _replace_frontmatter(MODELS[_row['model']])
        _description = (_row['review'] if _endpoint.startswith('app.routers.backups.') else
                        'Serialized ' + _row['model'] + '; declaration mirrors the existing handler response model.')
        _holes = schema_holes(_payload)
        if _holes:
            _status, _reason = 'incomplete', 'Existing model has unreviewed dynamic fields: ' + ', '.join(_holes)
    if _row['status_code'] == '204':
        _responses['204'] = {'description': 'Completed successfully; no response body.'}
        _description = 'No-content operation; success is HTTP 204.'
    elif _payload is not None:
        _responses[_row['status_code']] = json_response(_payload, _description)
    else:
        _status, _reason = 'incomplete', 'Success helper/storage-mode payload has not been fully declared; see pinned source evidence. No empty JSON schema substituted.'
        _responses[_row['status_code']] = {'description': 'Success body exists but its structure is not fully declared; see x-stella-contract-reason.', 'x-stella-body-undeclared': True}
    if _endpoint in {'app.routers.backups.download', 'app.routers.backups.download_head'}:
        _responses['200'] = _media(_row['review'], 'application/zip')
        _responses['200']['headers'] = {
            'Content-Length': {'schema': {'type': 'integer', 'minimum': 0}},
            'Content-Disposition': {'schema': S, 'description': 'Owned manifest ZIP filename; attachment disposition.'},
            'Content-Type': {'schema': {'type': 'string', 'const': 'application/zip'}},
            'Cache-Control': {'schema': {'type': 'string', 'const': 'no-store'}},
            'X-Content-Type-Options': {'schema': {'type': 'string', 'const': 'nosniff'}},
            'Referrer-Policy': {'schema': {'type': 'string', 'const': 'no-referrer'}},
        }
        _status, _reason, _description = 'reviewed', '', _row['review']
    if _endpoint in {'app.routers.admin_email.get_config', 'app.routers.oidc.jwks', 'app.routers.operations_status.change_audit'}:
        _responses['503'] = json_response(HTTP_ERROR, 'Controlled invalid public-source configuration; no rejected values returned.')
    if _endpoint == 'app.routers.auth.retired_invitation_api':
        _responses = {'410': json_response(HTTP_ERROR, 'Permanently retired invitation endpoint; never succeeds.')}
        _status, _reason, _description = 'reviewed', '', 'Retired in single-owner mode. Always HTTP 410; no successful JSON response.'
    if _endpoint in {'app.routers.auth.' + name for name in (
            'update_security', 'change_management_password', 'admin_setup', 'admin_unlock', 'admin_lock')}:
        _responses.pop('200', None)
        _responses['410'] = json_response(obj(detail=obj(
            code={'type': 'string', 'const': 'management_password_retired'}, message=S)),
            'Independent management password retired; authenticated owner receives 410 without mutation.')
        _status, _reason, _description = 'reviewed', '', 'Retired management-password API; no success or grant issuance. Owner authentication still required.'
    if _endpoint in {'app.routers.attachment.serve', 'app.routers.dynamic_assets.background_asset', 'app.routers.dynamic_assets.avatar_asset'}:
        _responses.update({'200': _media('Stored MIME bytes; local FileResponse or PostgreSQL blob materialization.'),
            '206': _media('FileResponse byte range or multipart/byteranges response.'),
            '304': {'description': 'Matching If-None-Match in PostgreSQL blob mode; no body.'},
            '400': {'description': 'Malformed range in FileResponse.', 'content': {'text/plain': {'schema': S}}},
            '416': {'description': 'Unsatisfiable byte range; no body.', 'headers': {'Content-Range': {'schema': S}}}})
        _status, _reason, _description = 'reviewed', '', 'Binary/media download. 304 is PostgreSQL-mode conditional handling; HEAD has no body. MIME varies by object.'
    if _endpoint == 'app.routers.task.download_speedtest_go':
        _responses['200'] = _media('Platform executable attachment; FileResponse MIME inferred from file.')
        _responses['206'] = _media('Range response.')
        _responses['400'] = {'description': 'Malformed range.', 'content': {'text/plain': {'schema': S}}}
        _responses['416'] = {'description': 'Unsatisfiable range; no body.'}
        _status, _reason, _description = 'reviewed', '', 'Binary executable download, not JSON.'
    if _endpoint in {'app.routers.monitor.' + n for n in ('agent_script', 'agent_install_sh', 'agent_install_ps1', 'agent_run_ps1', 'agent_hardware_sensors_ps1')}:
        _responses['200'] = {'description': 'Credential-free agent program/installer text.', 'content': {'text/plain': {'schema': S}}}
        _status, _reason, _description = 'reviewed', '', 'Plain text program or installer; not JSON.'
    if _endpoint == 'app.routers.website_settings.website_asset':
        _responses['200'] = {'description': 'Safe baseline or owner-only custom JavaScript.', 'content': {'application/javascript': {'schema': S}}}
        _status, _reason, _description = 'reviewed', '', 'JavaScript loader; persisted owner session controls custom content.'
    if _endpoint in {'app.routers.gallery.connect', 'app.routers.oidc.authorize'}:
        _responses.pop('200', None)
        _responses['307'] = {'description': 'RedirectResponse; destination in Location header.', 'headers': {'Location': {'schema': S}}}
        _status, _reason, _description = 'reviewed', '', 'HTTP 307 redirect, not a JSON URL. OIDC callback errors can also be redirected.'
    if _endpoint in {'app.routers.oidc.authorize', 'app.routers.oidc.token', 'app.routers.oidc.userinfo'}:
        for _code in (('400',) if _endpoint.endswith('authorize') else ('401',) if _endpoint.endswith('userinfo') else ('400', '401')):
            _responses[_code] = json_response(obj(error=S), 'OIDC protocol error, not FastAPI detail envelope.')
    if _endpoint == 'app.routers.drive.openlist_proxy':
        _responses.pop('200', None)
        if _row['method'] == 'OPTIONS':
            _responses['204'] = {'description': 'Local authenticated preflight; no upstream request or response body.', 'headers': {'Allow': {'schema': S}}}
            _status = 'reviewed'
        else:
            _responses['default'] = _media('Upstream status/MIME/bytes pass-through (HTML theme injection for uncompressed HTTP 200 HTML); no fixed JSON contract.')
            _status = 'passthrough'
        _reason = ''
        _description = 'Authenticated OpenList proxy. Upstream statuses and media are variable; OPTIONS is local 204. No fixed upstream JSON schema.'
    if _row['method'] == 'HEAD':
        for _response in _responses.values():
            _response.pop('content', None)
    if _row.get('model') in MODEL_BLOCKERS:
        _status, _reason = 'incomplete', MODEL_BLOCKERS[_row['model']]
    if _endpoint.removeprefix('app.routers.') in SHAPE_BLOCKERS:
        _status = 'incomplete'
    if _status == 'incomplete':
        _reason = INCOMPLETE_REASONS.get(_endpoint.removeprefix('app.routers.'), _reason)
        if not _description:
            _description = 'Response contract incomplete: ' + _reason
    DECLARATIONS[_key] = dict(endpoint=_endpoint, responses=_responses, status=_status, reason=_reason,
        description=_description, sources=_row['sources'])

DECLARATIONS[('GET', '/agent/release')]['responses']['200']['headers'] = {
    'Cache-Control': {'schema': {'type': 'string', 'const': 'no-store'}}}


# Revision-pinned upstream evidence retained as history; active mappings above
# are reconciled against this checkout, never auto-activated from a hash match.
TEMPLATE_INTEGRATION_EVIDENCE = {}
UPSTREAM_DECLARATIONS = {}
for _pending in json.loads((_BASE / 'api_response_upstream.json').read_text()):
    _method = _pending['method']
    _pending_responses = {code: json_response(HTTP_ERROR, 'Owner/management dependency or template operation failure.')
                          for code in ('401', '403', '503')}
    if _method == 'GET':
        _pending_responses['200'] = json_response(array({'anyOf': [BUILTIN_TEMPLATE, SAVED_TEMPLATE]}),
            'Built-in catalog plus owner-scoped saved portable templates; secrets and website addresses excluded.')
    elif _method == 'POST':
        _pending_responses.update({'201': json_response(SAVED_TEMPLATE, 'Saved template or same-key replay; identical response shape.'),
            '409': json_response(HTTP_ERROR, 'Idempotency content conflict or deleted original template.'),
            '413': json_response(HTTP_ERROR, 'Body exceeds bounded template upload budget.'),
            '422': json_response(VALIDATION_ERROR, 'Sanitized route validation or explicit template error.')})
    else:
        _pending_responses.update({'204': {'description': 'Deleted; no body.'}, '404': json_response(HTTP_ERROR, 'Missing, foreign or built-in template.')})
    TEMPLATE_INTEGRATION_EVIDENCE[(_method, _pending['path'])] = dict(_pending, responses=_pending_responses)
    _active = DECLARATIONS[(_method, _pending['path'])]
    _active.update(responses=_pending_responses, status='reviewed', reason='',
                   description='Owner-scoped portable template; no website addresses or credentials exported.')
    if _method == 'DELETE':
        # Full-main adds validation for the typed path parameter. Keep the active
        # offline declaration in parity without rewriting historical evidence.
        _active['responses'] = {**_pending_responses, '422': json_response(
            VALIDATION_ERROR, 'Typed path request validation.')}

for _merged in json.loads((_BASE / 'api_response_alerts_upstream.json').read_text())['operations']:
    if _merged['endpoint'] in SUCCESS:
        continue  # the stored list uses its real public serialization model
    _active = DECLARATIONS[(_merged['method'], _merged['path'])]
    _active.update(responses=_merged['responses'], status=_merged['status'], reason=_merged.get('reason', ''),
                   description='Merged metric alert contract; legacy rules remain separately filtered to schema_version=1.')
    if '422' in _active['responses']:
        _active['responses']['422'] = json_response(VALIDATION_ERROR, 'Shared public request validation or explicit metric-rule business error.')


_notes_pending = json.loads((_BASE / 'api_response_notes_upstream.json').read_text())
_UUID = {'type': 'string', 'format': 'uuid'}
DELETE_PREVIEW = obj(scope_token=S, target_ids=array(_UUID), descendant_count={'type':'integer','minimum':0},
    mode={'enum':['trash','permanent','empty-trash']},cascade=B,workspace_id=_UUID,doc_id=nullable(_UUID))
_notes_responses = {code:json_response(HTTP_ERROR,'Owner/session or lookup failure.') for code in ('401','403','404','503')}
_notes_responses.update({
    '200':json_response(DELETE_PREVIEW,'Read-only complete active+trash scope, rolled back after read. scope_token is a ten-minute comparison fingerprint, never authorization.'),
    '409':json_response(obj(detail=obj(code={'enum':['document_tree_invalid','document_tree_check_incomplete']},message=S)),
        'Invalid/incomplete tree, bounded lock/statement timeout or reported connection failure; never a partial inventory.'),
    '422':json_response(VALIDATION_ERROR,'Invalid mode/root/cascade input.')})
DECLARATIONS[('POST','/documents/delete-preview')].update(responses=_notes_responses, status='reviewed', reason='',
    description='Merged read-only deletion scope preview; no token authorization or persisted receipt.')
for _key in [('DELETE','/documents/{doc_id}'), ('DELETE','/documents/{doc_id}/permanent'), ('POST','/documents/trash/empty')]:
    DECLARATIONS[_key]['responses']['409'] = json_response(HTTP_ERROR, 'Tree/reference conflict or delete_scope_changed (code/message); zero partial writes.')
for _name in ('apply','rollback'):
    _key=('POST', '/external-modules/{mid}/injection/'+_name)
    DECLARATIONS[_key]['responses']['409'] = json_response(HTTP_ERROR, 'No prior version, origin mismatch, or incomplete_injection with typed projection marker.')


def _definitions(schema):
    """Collect response-local definitions before promoting them to document scope."""
    definitions = {}
    def visit(value):
        if isinstance(value, dict):
            for name, definition in value.get('$defs', {}).items():
                if name in definitions and definitions[name] != definition:
                    raise ValueError('Conflicting response-local definition: ' + name)
                definitions[name] = definition
            for child in value.values(): visit(child)
        elif isinstance(value, list):
            for child in value: visit(child)
    visit(schema)
    return definitions


def _definition_names(definitions):
    import hashlib
    return {name: ('StellaResponseJsonValue' if name == 'JsonValue' else
        'StellaResponse' + name + '_' + hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()[:12])
        for name, value in definitions.items()}


def _openapi_schema(schema, definitions=None):
    """Promote ALL local refs, including discriminator mappings, not just JSONValue."""
    names = _definition_names(_definitions(schema) if definitions is None else definitions)
    names['JsonValue'] = 'StellaResponseJsonValue'
    def visit(value):
        if isinstance(value, str) and value.startswith('#/$defs/'):
            name = value.removeprefix('#/$defs/')
            return '#/components/schemas/' + names[name]
        if isinstance(value, dict):
            return {k: visit(v) for k, v in value.items() if k != '$defs'}
        if isinstance(value, list):
            return [visit(v) for v in value]
        return value
    return visit(schema)


def _build_response_components():
    result = {name: _openapi_schema(value) for name, value in {
        'StellaHTTPError': HTTP_ERROR, 'StellaValidationError': VALIDATION_ERROR,
        'StellaResponseJsonValue': JSON_VALUE}.items()}
    for record in DECLARATIONS.values():
        for response in record['responses'].values():
            for media in response.get('content', {}).values():
                definitions = _definitions(media.get('schema', {}))
                names = _definition_names(definitions)
                for name, definition in definitions.items():
                    result[names[name]] = _openapi_schema(definition, definitions)
    return result


# Lane-specific response overrides follow all historical declarations. Keep the
# three notification-context incomplete records unchanged.
for _override in _V5_REVIEW['response_overrides']:
    _active = DECLARATIONS[(_override['method'], _override['path'])]
    for _field in ('responses', 'status', 'reason', 'description'):
        _active[_field] = deepcopy(_override[_field])


for _override in _V6_REVIEW['success_schema_replacements']:
    _active = DECLARATIONS[(_override['method'], _override['path'])]
    if _active['endpoint'] != _override['endpoint']:
        raise ValueError('v6 DTO operation precondition drift')
    for _code, _schema in _override['success_schema_replacements'].items():
        _active['responses'][_code]['content']['application/json']['schema'] = deepcopy(_schema)

for _override in _V8_REVIEW['success_schema_replacements']:
    _active = DECLARATIONS[(_override['method'], _override['path'])]
    if _active['endpoint'] != _override['endpoint']:
        raise ValueError('v8 DTO operation precondition drift')
    for _code, _schema in _override['success_schema_replacements'].items():
        _active['responses'][_code]['content']['application/json']['schema'] = deepcopy(_schema)

_RESPONSE_COMPONENTS = _build_response_components()


def response_components():
    # Build once from the immutable reviewed registry, isolate every caller.
    return deepcopy(_RESPONSE_COMPONENTS)


def decorate_response(operation, method, path, endpoint, *, document=None):
    record = DECLARATIONS.get((method.upper(), path))
    if record is None or record['endpoint'] != endpoint:
        operation['x-stella-contract-status'] = 'unclassified'
        operation['x-stella-contract-reason'] = 'No exact reviewed response contract for method/path/callable.'
        return
    # Preserve request/schema/security extensions and pre-existing typed response
    # models for incomplete routes. Replace only declared status codes; never keep
    # FastAPI's fictitious 200 on redirects, retirement, 204 or proxy operations.
    responses = deepcopy(record['responses'])
    original = operation.get('responses', {})
    if record['status'] == 'incomplete':
        for code, value in original.items():
            if code not in responses:
                responses[code] = deepcopy(value)
    if '422' in original or '422' in responses:
        responses['422'] = json_response(VALIDATION_ERROR, 'Global and private-route validation use the shared public loc/type/msg builder: schema-owned fields/indexes retained, dynamic keys/union labels redacted, constant messages/types. Explicit business HTTPException and logs are not covered by a global redaction claim.')
    if method.upper() == 'HEAD':
        for response in responses.values():
            response.pop('content', None)
    if document is not None:
        components = document.setdefault('components', {}).setdefault('schemas', {})
        components.update(response_components())
        for response in responses.values():
            for media in response.get('content', {}).values():
                payload = media.get('schema')
                if payload == HTTP_ERROR:
                    media['schema'] = {'$ref': '#/components/schemas/StellaHTTPError'}
                elif payload == VALIDATION_ERROR:
                    media['schema'] = {'$ref': '#/components/schemas/StellaValidationError'}
                elif payload is not None:
                    media['schema'] = _openapi_schema(payload)
    operation['responses'] = responses
    operation['x-stella-contract-status'] = record['status']
    operation['x-stella-contract-reason'] = record['reason']
    operation['x-stella-contract-evidence'] = {
        'handler': deepcopy(SOURCE_EVIDENCE[
            _V5_HANDLERS.get(record['endpoint'], record['endpoint'])]),
        'source-map': ('app/api_response_v8_review.json' if endpoint in _V8_ENDPOINTS
                       else ['app/api_response_v6_integration.json', 'app/api_response_ipv6_udp_source_review.json']
                       if endpoint in _V6_ENDPOINTS and endpoint in _IPV6_UDP_REVIEW['source_map_union']
                       else 'app/api_response_v6_integration.json' if endpoint in _V6_ENDPOINTS
                       else _IPV6_UDP_REVIEW['source_map_union'][endpoint] if endpoint in _IPV6_UDP_REVIEW['source_map_union']
                       else 'app/api_response_node_interruptions_review.json' if endpoint in _NODE_INTERRUPTION_ENDPOINTS
                       else 'app/api_response_v5_integration.json' if endpoint in _V5_ENDPOINTS
                       else 'app/api_response_round4_review.json' if endpoint in _ROUND4_ENDPOINTS
                       else 'app/api_response_auth_review.json' if endpoint in _AUTH_REVIEW['sources']
                       else 'app/api_response_backups.json' if endpoint.startswith('app.routers.backups.')
                       else 'app/api_response_inventory.json'),
        'supporting-symbols': list(record['sources']),
    }
    operation['x-stella-contract-validation'] = 'Documentation only; no new runtime response filtering, input validation or redaction.'
    if record['description']:
        operation['description'] = record['description']


def response_contract_errors(operation, method, path, endpoint, *, require_complete=False):
    record = DECLARATIONS.get((method.upper(), path))
    if record is None or record['endpoint'] != endpoint:
        return ['unclassified response contract (missing or stale exact operation review)']
    expected = deepcopy(operation)
    decorate_response(expected, method, path, endpoint, document={})
    errors = []
    for field in ('responses', 'x-stella-contract-status', 'x-stella-contract-reason'):
        if operation.get(field) != expected.get(field):
            errors.append('response contract differs from reviewed declaration: ' + field)
    for code, response in record['responses'].items():
        if record['status'] != 'reviewed':
            continue
        for media in response.get('content', {}).values():
            holes = schema_holes(media.get('schema', {}))
            if holes:
                errors.append(f'reviewed response {code} has unconstrained schema: {holes}')
    if require_complete and record['status'] == 'incomplete':
        errors.append('incomplete response contract: ' + record['reason'])
    return errors


def validate_response_sources(root, records):
    """Offline fail-closed inventory/source gate; never called by HTTP handlers.

    The caller supplies an independently discovered mounted inventory. Changes
    to any pinned supporting file require source review, not auto-acceptance.
    """
    import hashlib
    actual = {(method.upper(), path): endpoint for method, path, endpoint, _ in records}
    expected = {key: value['endpoint'] for key, value in DECLARATIONS.items()}
    errors = []
    for key in sorted(set(actual) | set(expected)):
        if actual.get(key) != expected.get(key):
            errors.append(f'{key}: unclassified/new, stale or changed response operation')
    checked = set()
    for row in INVENTORY:
        for symbol in row['sources']:
            source = SOURCE_EVIDENCE[symbol]
            identity = (source['file'], source['sha256'])
            if identity in checked:
                continue
            checked.add(identity)
            path = Path(root) / source['file']
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != source['sha256']:
                errors.append('source drift or missing source: ' + source['file'])
    return errors

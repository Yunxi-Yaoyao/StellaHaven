"""宿主机（Stella 宿主本机）检测与一键安装。"""
import platform
import os
import shutil
import subprocess
import json
from pathlib import Path
from app.services.agent_install import install_privileges, remove_legacy_docker_grants, _root_file

AGENT_SERVICE = "stella-agent"
AGENT_DIR = "/opt/stella-agent"


def detect_os() -> str:
    """本机 OS（静态，探一次存进节点 platform）。Linux 取发行版名（Ubuntu/CentOS/Debian/Arch…）。"""
    system = platform.system()
    if system == "Linux":
        return _linux_distro()
    return system.lower()


def _linux_distro() -> str:
    """读 /etc/os-release 取发行版友好名（CentOS Linux→CentOS，Debian GNU/Linux→Debian）。"""
    name = ""
    try:
        info = platform.freedesktop_os_release()  # Python 3.10+
        name = info.get("NAME", "")
    except Exception:
        pass
    if not name:
        try:
            with open("/etc/os-release", encoding="utf-8") as f:
                for line in f:
                    if line.startswith("NAME="):
                        name = line.split("=", 1)[1].strip().strip('"').strip("'")
                        break
        except Exception:
            pass
    for suffix in (" GNU/Linux", " Linux"):
        if name.endswith(suffix):
            name = name[: -len(suffix)]
            break
    return name or "linux"


def supports_local_install() -> bool:
    """A container's local process namespace is not the managed host."""
    return not (os.environ.get('KUBERNETES_SERVICE_HOST') or Path('/.dockerenv').exists() or Path('/run/.containerenv').exists())


def is_agent_installed() -> bool:
    """agent 是否在运行（动态，每次查 systemctl/pgrep）。"""
    return _is_agent_installed()


def _is_agent_installed() -> bool:
    if shutil.which("systemctl"):
        try:
            r = subprocess.run(["systemctl", "is-active", AGENT_SERVICE],
                               capture_output=True, text=True, timeout=5)
            if r.returncode == 0:
                return True
        except (OSError, subprocess.TimeoutExpired):
            pass
    if shutil.which("pgrep"):
        try:
            r = subprocess.run(["pgrep", "-f", "stella_agent.py"],
                               capture_output=True, timeout=5)
            if r.returncode == 0:
                return True
        except (OSError, subprocess.TimeoutExpired):
            pass
    return False


def install_host(token: str, center_url: str = "http://127.0.0.1:12031") -> dict:
    """Use the same authenticated instance installer as CLI, never legacy grants."""
    import re
    if any(c in token + center_url for c in '\r\n'):
        raise ValueError('invalid agent configuration')
    script = Path(__file__).resolve().parents[2] / 'agent' / 'install.sh'
    result = subprocess.run(['/bin/bash', str(script), '--url', center_url, '--no-deps'],
        env={**os.environ, 'STELLA_TOKEN': token}, capture_output=True, text=True, timeout=180)
    if result.returncode != 0:
        raise ValueError('Agent instance installation failed; existing ownership was not adopted')
    match = re.search(r'stella-agent-[a-f0-9]{24}', result.stdout)
    if not match:
        raise ValueError('Agent instance install receipt missing')
    return {'installed': True, 'service': match.group(0)}


def uninstall_host() -> None:
    """Unscoped center-side removal must never target the legacy host service."""
    raise ValueError('Explicit authenticated agent instance is required for uninstall')


def _ensure_user() -> None:
    """创建独立系统用户 stella（PBR 按 UID 识别 + 最小权限）。"""
    if shutil.which("id"):
        r = subprocess.run(["id", "-u", "stella"], capture_output=True)
        if r.returncode == 0:
            return
    if shutil.which("useradd"):
        subprocess.run(["useradd", "--system", "--no-create-home",
                        "--shell", "/usr/sbin/nologin", "stella"],
                       check=False, capture_output=True)


def _ensure_sudoers() -> None:
    """Install explicit uninstall rules, retain authorized networking, remove old Docker grant."""
    sysctl = shutil.which("systemctl") or "/usr/sbin/systemctl"
    rm = shutil.which("rm") or "/usr/bin/rm"
    content = (
        f"stella ALL=(root) NOPASSWD: {sysctl} stop stella-agent, "
        f"{sysctl} disable stella-agent, {sysctl} daemon-reload, "
        f"{rm} -f /etc/systemd/system/stella-agent.service, "
        f"{rm} -rf /opt/stella-agent\n"
    )
    p = Path("/etc/sudoers.d/stella-uninstall")
    existing = remove_legacy_docker_grants(p.read_text()) if p.exists() else ''
    # New rules are one command per line; do not erase prior network/WG grants.
    prefix = 'stella ALL=(root) NOPASSWD: '
    commands = content.strip()[len(prefix):].split(', ')
    lines: list[str] = [str(line) for line in existing.splitlines()]
    for command in commands:
        line = prefix + command
        if line not in lines:
            lines.append(line)
    visudo = shutil.which('visudo')
    if not visudo:
        raise RuntimeError('visudo required')
    _root_file(p, '\n'.join(lines) + '\n', 0o440,
               lambda stage: subprocess.run([visudo, '-cf', stage], check=True,
                                             capture_output=True, timeout=10))
